package com.hvh.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class HvhClient implements ClientModInitializer {
    public static boolean preHit = false;

    private boolean kWasDown = false;
    private boolean swapBack = false;

    @Override
    public void onInitializeClient() {
        // K tusu sabit: KeyBinding kullanilmadigi icin kontrol ayarlarinda gorunmez
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            long window = mc.getWindow().getHandle();
            boolean down = InputUtil.isKeyPressed(window, GLFW.GLFW_KEY_K);
            if (down && !kWasDown && mc.currentScreen == null && mc.player != null) {
                mc.setScreen(new PreHitScreen());
            }
            kWasDown = down;

            // Vurustan sonraki tick'te eski slota don
            if (swapBack && mc.player != null && mc.getNetworkHandler() != null) {
                mc.getNetworkHandler().sendPacket(
                        new UpdateSelectedSlotC2SPacket(mc.player.getInventory().selectedSlot));
                swapBack = false;
            }
        });

        // PreHit: fisek elindeyken vurunca, vurustan hemen once kilic slotuna gecir
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!world.isClient || !preHit) return ActionResult.PASS;
            if (!player.getMainHandStack().isOf(Items.FIREWORK_ROCKET)) return ActionResult.PASS;

            int sword = -1;
            for (int i = 0; i < PlayerInventory.getHotbarSize(); i++) {
                if (player.getInventory().getStack(i).getItem() instanceof SwordItem) {
                    sword = i;
                    break;
                }
            }
            if (sword == -1) return ActionResult.PASS;

            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.getNetworkHandler() == null) return ActionResult.PASS;
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(sword));
            swapBack = true;
            return ActionResult.PASS;
        });
    }
}
